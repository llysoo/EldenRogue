
package View;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

public class Shop extends javax.swing.JFrame {
    // Player's inventory to store purchased swords
    private List<String> inventory;    
    private String selectedClass;
    private int availRunes;
    private String playerName;
    private int currentLevel;
    private int currentHealth;
    private int currentDEX;
    private int currentSTR;
    private int currentINT;
    private int currentEND;
    private int currentFTH;
    private static final int IMAGE_SIZE = 100;
   
    public Shop(int runes, String playerName, String selectedClass, int initialLevel, int initialHealth, int initialDEX, int initialSTR, int initialINT, int initialEND, int initialFTH) {
        initComponents();
        setSwordImages();
        addClickListeners();
        
        // Set the available runes
        this.totalRune.setText(String.valueOf(runes));
        
        this.availRunes = runes;
        this.selectedClass = selectedClass;
        this.playerName = playerName;
        this.currentLevel = initialLevel;
        this.currentHealth = initialHealth;
        this.currentDEX = initialDEX;
        this.currentSTR = initialSTR;
        this.currentINT = initialINT;
        this.currentEND = initialEND;
        this.currentFTH = initialFTH;
        System.out.println("Available Runes: " + availRunes);
        // Initialize the player's inventory
        this.inventory = new ArrayList<>();
    }
private void buyWeapon(String weaponName, String imagePath) {
  // Implement logic for buying the weapon (deduct runes, etc.)

    // Add the purchased weapon to the player's inventory
  inventory.add(weaponName);

  // Create a new Weapon instance
  Weapon purchasedWeapon = new Weapon(weaponName, imagePath);

}
 private void addClickListeners() {
    // Add a MouseListener to shortSword
    shortSword.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // Handle the click event for Short Sword
            handleSwordClick(shortSword, "Short Sword");
        }
    });

    // Add a MouseListener to rogiersSword
    rogiersSword.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // Handle the click event for Rogier's Sword
            handleSwordClick(rogiersSword, "Rogier's Sword");
        }
    });

    // Add a MouseListener to codedSword
    codedSword.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // Handle the click event for Coded Sword
            handleSwordClick(codedSword, "Coded Sword");
        }
    });

    // Add a MouseListener to swordNight
    swordNight.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // Handle the click event for Sword of Night and Flame
            handleSwordClick(swordNight, "Sword of Night and Flame");
        }
    });
}
private int getPriceForSword(String swordName) {
    // Implement logic to return the price for each sword
    // For example:
    if (swordName.equals("Short Sword")) {
        System.out.println("Available Runes: " + availRunes);
        return 1000;
    } else if (swordName.equals("Rogier's Sword")) {
        return 2000;
    } else if (swordName.equals("Coded Sword")) {
        return 4000;
    } else if (swordName.equals("Sword of Night and Flame")) {
        return 8000;
    } else {
        return 0; // Default price
    }
}
private void handleSwordClick(javax.swing.JLabel clickedSword, String swordName) {
    // Reset borders for all swords
    shortSword.setBorder(null);
    rogiersSword.setBorder(null);
    codedSword.setBorder(null);
    swordNight.setBorder(null);

    // Set the border for the clicked sword to indicate it's active
    clickedSword.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 2));

    // Show price notification
    int price = getPriceForSword(swordName); // You need to implement this method to get the price for each sword
  }
    private void setSwordImages() {
        // Set images for swords
        shortSword.setIcon(resizeImage("/elden/rogue/weapon/shortSword.png", 140, 270));
        rogiersSword.setIcon(resizeImage("/elden/rogue/weapon/rogiersSword.png", 140, 270));
        codedSword.setIcon(resizeImage("/elden/rogue/weapon/codedSword.png", 140, 270));
        swordNight.setIcon(resizeImage("/elden/rogue/weapon/swordNight.png", 140, 270));
    }
    private ImageIcon resizeImage(String path, int width, int height) {
        ImageIcon originalIcon = new ImageIcon(getClass().getResource(path));
        Image image = originalIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(image);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        totalRune = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        shortSword = new javax.swing.JLabel();
        rogiersSword = new javax.swing.JLabel();
        codedSword = new javax.swing.JLabel();
        swordNight = new javax.swing.JLabel();
        buy = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setForeground(new java.awt.Color(102, 0, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Available Runes:");

        totalRune.setForeground(new java.awt.Color(255, 204, 0));
        totalRune.setText("0");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("***SWORDS***");

        shortSword.setBackground(new java.awt.Color(153, 0, 0));

        rogiersSword.setBackground(new java.awt.Color(153, 0, 0));

        codedSword.setBackground(new java.awt.Color(153, 0, 0));

        swordNight.setBackground(new java.awt.Color(153, 0, 0));

        buy.setBackground(new java.awt.Color(51, 255, 51));
        buy.setText("BUY");
        buy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buyActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(204, 0, 0));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(289, 289, 289)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(41, 41, 41)
                                .addComponent(totalRune))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(shortSword, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(rogiersSword, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(codedSword, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(swordNight, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(290, 290, 290)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buy, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(totalRune))
                .addGap(34, 34, 34)
                .addComponent(jLabel2)
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(shortSword, javax.swing.GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)
                    .addComponent(rogiersSword, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(codedSword, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(swordNight, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(buy)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addGap(123, 123, 123))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 716, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 542, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void buyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buyActionPerformed
        // TODO add your handling code here:

        // Get the selected sword's name
        String selectedSwordName = getSelectedSwordName();
        // Check if a sword is selected
        if(selectedSwordName.isEmpty()) {
            // Notify the player that they need to select a sword first
            JOptionPane.showMessageDialog(this, "Please select a sword to purchase.", "No Sword Selected", JOptionPane.WARNING_MESSAGE);
            return; // Exit the method
        }
       // Get the price of the selected sword
       int swordPrice = getPriceForSword(selectedSwordName);

       // Check if the player has enough runes to buy the sword
       if (availRunes >= swordPrice) {
           // Deduct the price of the sword from available runes
           availRunes -= swordPrice;

           // Update the available runes label
           totalRune.setText(String.valueOf(availRunes));
           JOptionPane.showMessageDialog(this, "You have successfully bought the " + selectedSwordName + "!", "Purchase Successful", JOptionPane.INFORMATION_MESSAGE);

           // Proceed with the purchase (open the game lobby, etc.)
           this.dispose();
           GameLobby game = new GameLobby(availRunes, playerName, selectedClass, currentLevel, currentHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
           game.setVisible(true);
       } else {
           // Notify the player that they don't have enough runes to buy the sword
           JOptionPane.showMessageDialog(this, "You don't have enough runes to buy this sword.", "Insufficient Runes", JOptionPane.ERROR_MESSAGE);
       }

    }//GEN-LAST:event_buyActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
        GameLobby game = new GameLobby(availRunes, playerName, selectedClass, currentLevel, currentHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
        game.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed
    // Method to get the name of the selected sword
private String getSelectedSwordName() {
    if (shortSword.getBorder() != null) {
        return "Short Sword";
    } else if (rogiersSword.getBorder() != null) {
        return "Rogier's Sword";
    } else if (codedSword.getBorder() != null) {
        return "Coded Sword";
    } else if (swordNight.getBorder() != null) {
        return "Sword of Night and Flame";
    } else {
        return ""; // Default value
    }
}
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Shop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Shop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Shop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Shop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buy;
    private javax.swing.JLabel codedSword;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel rogiersSword;
    private javax.swing.JLabel shortSword;
    private javax.swing.JLabel swordNight;
    private javax.swing.JLabel totalRune;
    // End of variables declaration//GEN-END:variables
}
