
package View;


public class Main {


    public static void main(String[] args) {
        // TODO code application logic here
        
       TitleScreen screen = new TitleScreen();
       screen.setVisible(true);
    }
    
}
