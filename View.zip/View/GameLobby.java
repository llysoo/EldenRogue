
package View;


public class GameLobby extends javax.swing.JFrame {

    private String selectedClass;
    private int availRunes;
    private String playerName;
    private int currentLevel;
    private int currentHealth;
    private int currentDEX;
    private int currentSTR;
    private int currentINT;
    private int currentEND;
    private int currentFTH;
    
    public GameLobby(int runes, String playerName, String selectedClass, int initialLevel, int initialHealth, int initialDEX, int initialSTR, int initialINT, int initialEND, int initialFTH) {
        initComponents();
        System.out.println(playerName);
        this.availRunes = runes;
        this.selectedClass = selectedClass;
        this.playerName = playerName;
        this.currentLevel = initialLevel;
        this.currentHealth = initialHealth;
        this.currentDEX = initialDEX;
        this.currentSTR = initialSTR;
        this.currentINT = initialINT;
        this.currentEND = initialEND;
        this.currentFTH = initialFTH;
        System.out.println(runes);
        System.out.println("LIFE: " + currentHealth);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        FastTravel = new javax.swing.JButton();
        levelUp = new javax.swing.JButton();
        inventory = new javax.swing.JButton();
        shop = new javax.swing.JButton();
        quit = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 51, 51));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("GAME LOBBY");

        FastTravel.setBackground(new java.awt.Color(204, 204, 0));
        FastTravel.setFont(new java.awt.Font("SimSun", 0, 14)); // NOI18N
        FastTravel.setText("FAST TRAVEL");
        FastTravel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FastTravelActionPerformed(evt);
            }
        });

        levelUp.setBackground(new java.awt.Color(51, 255, 51));
        levelUp.setFont(new java.awt.Font("SimSun", 0, 14)); // NOI18N
        levelUp.setText("LEVEL UP");
        levelUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                levelUpActionPerformed(evt);
            }
        });

        inventory.setBackground(new java.awt.Color(0, 0, 255));
        inventory.setFont(new java.awt.Font("SimSun", 0, 14)); // NOI18N
        inventory.setForeground(new java.awt.Color(255, 255, 255));
        inventory.setText("INVENTORY");
        inventory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventoryActionPerformed(evt);
            }
        });

        shop.setBackground(new java.awt.Color(153, 153, 255));
        shop.setFont(new java.awt.Font("SimSun", 0, 14)); // NOI18N
        shop.setText("SHOP");
        shop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shopActionPerformed(evt);
            }
        });

        quit.setBackground(new java.awt.Color(153, 0, 0));
        quit.setFont(new java.awt.Font("SimSun", 1, 14)); // NOI18N
        quit.setForeground(new java.awt.Color(255, 255, 255));
        quit.setText("QUIT");
        quit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(167, 167, 167)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(FastTravel)
                        .addGap(18, 18, 18)
                        .addComponent(levelUp, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(inventory, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(shop, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(193, 193, 193)
                        .addComponent(quit, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addGap(86, 86, 86)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(levelUp)
                    .addComponent(FastTravel)
                    .addComponent(inventory)
                    .addComponent(shop))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE)
                .addComponent(quit)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void levelUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_levelUpActionPerformed
        // Create an instance of LevelUp
        LevelUp levelUpWindow = new LevelUp(availRunes, playerName, selectedClass, currentLevel, currentHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);

        // Make the LevelUp window visible
        levelUpWindow.setVisible(true);

        // Dispose the GameLobby frame
        this.dispose();
    }//GEN-LAST:event_levelUpActionPerformed

    private void FastTravelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FastTravelActionPerformed
        // TODO add your handling code here:
        this.dispose();
        
                       // Pass necessary information to the GameLobby
        FastTravel ft = new FastTravel(availRunes, playerName, selectedClass, currentLevel, currentHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
        ft.setVisible(true);
        ft.setVisible(true);
    }//GEN-LAST:event_FastTravelActionPerformed

    private void inventoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventoryActionPerformed
        // TODO add your handling code here:
        this.dispose();
        
        Inventory invent = new Inventory(availRunes, playerName, selectedClass, currentLevel, currentHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
        invent.setVisible(true);
    }//GEN-LAST:event_inventoryActionPerformed

    private void shopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shopActionPerformed
        // TODO add your handling code here:
        this.dispose();
        System.out.println("Available Runes: " + availRunes);
        Shop shop = new Shop(availRunes, playerName, selectedClass, currentLevel, currentHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
        shop.setVisible(true);
        
        
    }//GEN-LAST:event_shopActionPerformed

    private void quitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quitActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_quitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GameLobby.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GameLobby.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GameLobby.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GameLobby.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton FastTravel;
    private javax.swing.JButton inventory;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton levelUp;
    private javax.swing.JButton quit;
    private javax.swing.JButton shop;
    // End of variables declaration//GEN-END:variables
}
