
package View;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;


public class CharacterCreation extends javax.swing.JFrame {

    private String selectedClass;
    int initialRunes = 500;
    int initialLevel = 1;
    int initialHealth = 0;
    int initialDEX = 0;
    int initialSTR = 0;
    int initialINT = 0;
    int initialEND = 0;
    int initialFTH = 0;
    int availableRunes = 500;
    private GameLobby gameLobby;  // Reference to GameLobby
    
    private JButton selectedClassButton;  // To keep track of the selected class button

    public CharacterCreation(GameLobby gameLobby) {
        initComponents();
        setLocationRelativeTo(null);
        this.gameLobby = gameLobby;
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        vagabondClass = new javax.swing.JButton();
        samuraiClass = new javax.swing.JButton();
        warriorClass = new javax.swing.JButton();
        heroClass = new javax.swing.JButton();
        astrologerClass = new javax.swing.JButton();
        prophetClass = new javax.swing.JButton();
        confirm = new javax.swing.JButton();
        quitBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        playerName = new javax.swing.JTextField();
        imageClass = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));

        jLabel1.setBackground(new java.awt.Color(102, 0, 0));
        jLabel1.setFont(new java.awt.Font("Sitka Text", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 0, 0));
        jLabel1.setText("CHARACTER CREATION");

        vagabondClass.setText("VAGABOND");
        vagabondClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vagabondClassActionPerformed(evt);
            }
        });

        samuraiClass.setText("SAMURAI");
        samuraiClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                samuraiClassActionPerformed(evt);
            }
        });

        warriorClass.setText("WARRIOR");
        warriorClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                warriorClassActionPerformed(evt);
            }
        });

        heroClass.setText("HERO");
        heroClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                heroClassActionPerformed(evt);
            }
        });

        astrologerClass.setText("ASTROLOGER");
        astrologerClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                astrologerClassActionPerformed(evt);
            }
        });

        prophetClass.setText("PROPHET");
        prophetClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prophetClassActionPerformed(evt);
            }
        });

        confirm.setBackground(new java.awt.Color(0, 153, 0));
        confirm.setForeground(new java.awt.Color(255, 255, 255));
        confirm.setText("CONFIRM");
        confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmActionPerformed(evt);
            }
        });

        quitBtn.setBackground(new java.awt.Color(51, 0, 0));
        quitBtn.setForeground(new java.awt.Color(255, 255, 255));
        quitBtn.setText("BACK");
        quitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quitBtnActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Name:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(playerName, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(vagabondClass, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(warriorClass, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(heroClass, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(astrologerClass, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(samuraiClass, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(prophetClass, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(131, 131, 131)
                                .addComponent(imageClass, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 117, Short.MAX_VALUE)
                                .addComponent(jLabel1)))
                        .addGap(102, 102, 102))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(quitBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(confirm)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(playerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(vagabondClass)
                        .addGap(18, 18, 18)
                        .addComponent(samuraiClass)
                        .addGap(18, 18, 18)
                        .addComponent(warriorClass)
                        .addGap(18, 18, 18)
                        .addComponent(heroClass)
                        .addGap(18, 18, 18)
                        .addComponent(astrologerClass)
                        .addGap(18, 18, 18)
                        .addComponent(prophetClass)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(quitBtn)
                            .addComponent(confirm)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(imageClass, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void quitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quitBtnActionPerformed
        // TODO add your handling code here:
        this.dispose();
        TitleScreen ts = new TitleScreen();
        ts.setVisible(true);
    }//GEN-LAST:event_quitBtnActionPerformed

    private void confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmActionPerformed
        // TODO add your handling code here:
                                  
        String playerName = this.playerName.getText();

                // Check if the player name is empty
        if (playerName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a player name.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check if a class is chosen
        if (selectedClass == null) {
            JOptionPane.showMessageDialog(this, "Please choose a class.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        
        
        // Close the CharacterCreation window
        this.dispose();
        // Pass necessary information to the GameLobby
        GameLobby game = new GameLobby(initialRunes, playerName, selectedClass, initialLevel, initialHealth, initialDEX, initialSTR, initialINT, initialEND, initialFTH);

        // Make the GameLobby visible
        game.setVisible(true);
   
    }//GEN-LAST:event_confirmActionPerformed
    private void classButtonActionPerformed(ActionEvent evt, JButton classButton) {
        // Highlight the selected class button
        if (selectedClassButton != null) {
            selectedClassButton.setBackground(Color.WHITE);  // Reset the background of the previously selected button
        }
        selectedClassButton = classButton;
        classButton.setBackground(Color.YELLOW);  // Highlight the selected button

        // Set the selected class
        selectedClass = classButton.getText();
        
        // Set the image based on the selected class
        setClassImage(selectedClass);
    }
    private void vagabondClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vagabondClassActionPerformed
        // TODO add your handling code here:
        // Get the player's name
        String playerName = this.playerName.getText();

        selectedClass = "Vagabond";
        
        initialLevel = 9;
        initialHealth = 15;
        initialDEX = 13;
        initialSTR = 14;
        initialINT = 9;
        initialEND = 11;
        initialFTH = 9;
        
        // Set the image based on the selected class
        setClassImage(selectedClass);
        // Create an object of LevelUp and pass the necessary information
        LevelUp levelUp = new LevelUp(availableRunes, playerName, selectedClass, initialLevel, initialHealth, initialDEX, initialSTR, initialINT, initialEND, initialFTH);

    }//GEN-LAST:event_vagabondClassActionPerformed

    private void samuraiClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_samuraiClassActionPerformed
        // TODO add your handling code here:
                // Get the player's name
        String playerName = this.playerName.getText();

        selectedClass = "Samurai";
        initialLevel = 9;
        initialHealth = 12;
        initialDEX = 15;
        initialSTR = 12;
        initialINT = 9;
        initialEND = 13;
        initialFTH = 8;
        
        // Set the image based on the selected class
        setClassImage(selectedClass);
        // Set the image based on the selected class
        setClassImage(selectedClass);
        // Create an object of LevelUp and pass the necessary information
        LevelUp levelUp = new LevelUp(availableRunes, playerName, selectedClass, initialLevel, initialHealth, initialDEX, initialSTR, initialINT, initialEND, initialFTH);

    }//GEN-LAST:event_samuraiClassActionPerformed

    private void warriorClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_warriorClassActionPerformed
        // TODO add your handling code here:
                // Get the player's name
        String playerName = this.playerName.getText();

        selectedClass = "Warrior";
        initialLevel = 9;
        initialHealth = 11;
        initialDEX = 16;
        initialSTR = 14;
        initialINT = 10;
        initialEND = 11;
        initialFTH = 8;
        
        // Set the image based on the selected class
        setClassImage(selectedClass);
        // Create an object of LevelUp and pass the necessary information
        LevelUp levelUp = new LevelUp(availableRunes, playerName, selectedClass, initialLevel, initialHealth, initialDEX, initialSTR, initialINT, initialEND, initialFTH);

    }//GEN-LAST:event_warriorClassActionPerformed

    private void heroClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_heroClassActionPerformed
        // TODO add your handling code here:
                String playerName = this.playerName.getText();

        selectedClass = "Hero";
        initialLevel = 7;
        initialHealth = 14;
        initialDEX = 9;
        initialSTR = 16;
        initialINT = 7;
        initialEND = 12;
        initialFTH = 8;
        
        // Set the image based on the selected class
        setClassImage(selectedClass);       
        // Create an object of LevelUp and pass the necessary information
        LevelUp levelUp = new LevelUp(availableRunes, playerName, selectedClass, initialLevel, initialHealth, initialDEX, initialSTR, initialINT, initialEND, initialFTH);

    }//GEN-LAST:event_heroClassActionPerformed
    private void setClassImage(String className) {
        // Load an image based on the class name
        String imagePath = "/elden/rogue/class/" + className.toLowerCase() + ".png"; // Adjust the path accordingly
        ImageIcon icon = new ImageIcon(getClass().getResource(imagePath));
        

        // Set the desired size for the image (adjust width and height as needed)
        int width = 200;
        int height = 200;
        Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);

        // Set the scaled image to the imageClass JLabel
        imageClass.setIcon(new ImageIcon(scaledImage));
    }
    private void astrologerClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_astrologerClassActionPerformed
        // TODO add your handling code here:
                String playerName = this.playerName.getText();

        selectedClass = "Astrologer";
        initialLevel = 6;
        initialHealth = 9;
        initialDEX = 12;
        initialSTR = 8;
        initialINT = 16;
        initialEND = 9;
        initialFTH = 7;
          
        // Set the image based on the selected class
        setClassImage(selectedClass);  
        // Create an object of LevelUp and pass the necessary information
        LevelUp levelUp = new LevelUp(availableRunes, playerName, selectedClass, initialLevel, initialHealth, initialDEX, initialSTR, initialINT, initialEND, initialFTH);

    }//GEN-LAST:event_astrologerClassActionPerformed

    private void prophetClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prophetClassActionPerformed
        // TODO add your handling code here:
                String playerName = this.playerName.getText();

        selectedClass = "Prophet";
        initialLevel = 7;
        initialHealth = 10;
        initialDEX = 10;
        initialSTR = 11;
        initialINT = 7;
        initialEND = 8;
        initialFTH = 16;
        // Set the image based on the selected class
        setClassImage(selectedClass);         
        // Create an object of LevelUp and pass the necessary information
        LevelUp levelUp = new LevelUp(availableRunes, playerName, selectedClass, initialLevel, initialHealth, initialDEX, initialSTR, initialINT, initialEND, initialFTH);

    }//GEN-LAST:event_prophetClassActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CharacterCreation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CharacterCreation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CharacterCreation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CharacterCreation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton astrologerClass;
    private javax.swing.JButton confirm;
    private javax.swing.JButton heroClass;
    private javax.swing.JLabel imageClass;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField playerName;
    private javax.swing.JButton prophetClass;
    private javax.swing.JButton quitBtn;
    private javax.swing.JButton samuraiClass;
    private javax.swing.JButton vagabondClass;
    private javax.swing.JButton warriorClass;
    // End of variables declaration//GEN-END:variables
}
