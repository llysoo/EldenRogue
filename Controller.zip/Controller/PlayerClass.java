package Controller;

public class PlayerClass {
    private String className;
    private int hp;
    private int dex;
    private int str;
    private int intel;
    private int end;
    private int fth;

    public PlayerClass(String className, int hp, int dex, int str, int intel, int end, int fth) {
        this.className = className;
        this.hp = hp;
        this.dex = dex;
        this.str = str;
        this.intel = intel;
        this.end = end;
        this.fth = fth;
    }

    // Add getter methods for each statistic
    public String getClassName() {
        return className;
    }

    public int getHp() {
        return hp;
    }

    public int getDex() {
        return dex;
    }

    public int getStr() {
        return str;
    }

    public int getIntelligence() {
        return intel;
    }

    public int getEndurance() {
        return end;
    }

    public int getFaith() {
        return fth;
    }
}