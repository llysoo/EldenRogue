
package elden;


public class PlayerStatistics {
       private int level;
    private int health;
    private int dexterity;
    private int strength;
    private int intelligence;
    private int endurance;
    private int faith;

    public PlayerStatistics(int level, int health, int dexterity, int strength, int intelligence, int endurance, int faith) {
        this.level = level;
        this.health = health;
        this.dexterity = dexterity;
        this.strength = strength;
        this.intelligence = intelligence;
        this.endurance = endurance;
        this.faith = faith;
    }

    // Getters for each statistic
    public int getLevel() {
        return level;
    }

    public int getHealth() {
        return health;
    }

    public int getDexterity() {
        return dexterity;
    }

    public int getStrength() {
        return strength;
    }

    public int getIntelligence() {
        return intelligence;
    }

    public int getEndurance() {
        return endurance;
    }

    public int getFaith() {
        return faith;
    }
}
