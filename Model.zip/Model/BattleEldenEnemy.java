
package Model;

import View.GameLobby;
import javax.swing.JOptionPane;


public class BattleEldenEnemy extends javax.swing.JFrame {
    private static final int ROWS = 7;
    private static final int COLS = 3;
    private char[][] floor1;
    private char[][] floor2;
    private char[][] floor3; // Added floor3
    private int currentFloor;
    private int enemyHP;
    private String enemy;
    private int totalRunes;
    private String selectedClass;
    private int currentLevel;
    private int pHealth;
    private int currentDEX;
    private String player;
    private int currentSTR;
    private int currentINT;
    private int currentEND;
    private int currentFTH;
    private int enemyMaxHP;
    private int weaponSTR; 
    private int weaponINT;
    private int weaponFTH; 
    private int Health;
    private int playerHealth;
    private int playerPhysicalDamage;
    private BattleElden battleElden; // Add a reference to StormBattle

    public BattleEldenEnemy(int runes, String enemyName, int currentFloor, String name, int initialLevel, int initialHealth, int initialDEX, int initialSTR, int initialINT, int initialEND, int initialFTH, BattleElden battleElden) {
        initComponents();
        setLocationRelativeTo(null);
        enemyType.setText(enemyName);
        this.player = name;
        // Randomize enemy HP based on floor and a range (20-30)
        int baseHP = 20;
        int hpRange = 10; // The range of HP variation
        int minHP = baseHP + (currentFloor - 1) * hpRange;
        int maxHP = minHP + hpRange;
        this.battleElden = battleElden; 
        this.pHealth = initialHealth;
        int weaponHealth = 0;
        initialHealth = 100 * ((initialHealth + weaponHealth) / 2);
        this.Health = initialHealth;
        this.enemy = enemyName;
        playerName.setText(String.valueOf(name));
        playerHP.setText(String.valueOf(initialHealth));
        playerLevel.setText(String.valueOf(initialLevel));
        playerName.setText(String.valueOf(name));
        playerHP.setText(String.valueOf(initialHealth));
        playerLevel.setText(String.valueOf(initialLevel));
        this.playerHealth = initialHealth;
        this.currentLevel = initialLevel;
        this.totalRunes = runes;
        this.currentDEX = initialDEX;
        this.currentSTR = initialSTR;
        this.currentINT = initialINT;
        this.currentEND = initialEND;
        this.currentFTH = initialFTH;
        this.weaponSTR = 0;
        this.weaponINT = 0;
        this.weaponFTH = 0;
        if(enemyType.equals("The Elden Beast")){
            this.enemyHP = 800;
            this.enemyMaxHP = enemyHP;
            System.out.println(enemyHP);
        }
        enemyHealth.setText(String.valueOf(enemyHP));
    }
    private double getEnemyPhysicalDefense() {
        switch (enemy) {
            case "The Elden Beast":
                return 0.25;
            default:
                return 0.0;
        }
    }
    private double getEnemySorceryDefense() {
        switch (enemy) {
            case "The Elden Beast":
                return 0.50;
            default:
                return 0.0;
        }
    }

    private double getEnemyIncantationDefense() {
        switch (enemy) {
            case "The Elden Beast":
                return 0.40;
            default:
                return 0.0;
        }
    }                                       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        playerName = new javax.swing.JLabel();
        playerLevel = new javax.swing.JLabel();
        playerHP = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        enemyType = new javax.swing.JLabel();
        enemyHealth = new javax.swing.JLabel();
        physicalAttack = new javax.swing.JButton();
        sorcererAttack = new javax.swing.JButton();
        incantationAttack = new javax.swing.JButton();
        battleText = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Viner Hand ITC", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 204));
        jLabel1.setText("ELDEN THRONE BATTLE");

        jLabel2.setForeground(new java.awt.Color(255, 51, 51));
        jLabel2.setText("Player Name:");

        jLabel3.setForeground(new java.awt.Color(255, 51, 51));
        jLabel3.setText("Player Level:");

        jLabel4.setForeground(new java.awt.Color(255, 51, 51));
        jLabel4.setText("Health:");

        playerName.setForeground(new java.awt.Color(255, 51, 51));
        playerName.setText("jLabel5");

        playerLevel.setForeground(new java.awt.Color(255, 51, 51));
        playerLevel.setText("jLabel6");

        playerHP.setForeground(new java.awt.Color(255, 51, 51));
        playerHP.setText("jLabel7");

        jLabel5.setForeground(new java.awt.Color(255, 51, 51));
        jLabel5.setText("Enemy Name:");

        jLabel6.setForeground(new java.awt.Color(255, 51, 51));
        jLabel6.setText("Health:");

        enemyType.setForeground(new java.awt.Color(255, 51, 51));
        enemyType.setText("jLabel7");

        enemyHealth.setForeground(new java.awt.Color(255, 51, 51));
        enemyHealth.setText("jLabel8");

        physicalAttack.setText("PHYSICAL ATTACK");
        physicalAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                physicalAttackActionPerformed(evt);
            }
        });

        sorcererAttack.setText("SORCERER ATTACK");
        sorcererAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sorcererAttackActionPerformed(evt);
            }
        });

        incantationAttack.setText("INCANTATION ATTACK");
        incantationAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                incantationAttackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel2)
                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(physicalAttack))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(sorcererAttack)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(incantationAttack, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(playerName)
                            .addComponent(playerLevel)
                            .addComponent(playerHP))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGap(59, 59, 59)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(enemyType)
                            .addComponent(enemyHealth))
                        .addGap(64, 64, 64))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addComponent(battleText, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(playerName)
                    .addComponent(jLabel5)
                    .addComponent(enemyType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(playerLevel)
                    .addComponent(jLabel6)
                    .addComponent(enemyHealth))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(playerHP))
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(physicalAttack)
                    .addComponent(sorcererAttack)
                    .addComponent(incantationAttack))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(battleText, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>                        

    private void incantationAttackActionPerformed(java.awt.event.ActionEvent evt) {                                                  
                // Calculate player's incantation damage
        int playerIncantationDamage = (int) ((currentFTH + weaponFTH) * (1 - getEnemyIncantationDefense()));
        // Update enemy health
        enemyHP -= playerPhysicalDamage;
        enemyHealth.setText(String.valueOf(enemyHP));
        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            if(enemy == "The Elden Beast"){
               JOptionPane.showMessageDialog(this, "Greate Enemy Felled!"); 
            }
            int runesGained = enemyMaxHP * 5;
            battleElden.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            // Update enemy health
            enemyHP -= playerIncantationDamage;
            enemyHealth.setText(String.valueOf(enemyHP));
            // Display battle text
            battleText.setText("Player used INCANTATION ATTACK. Damage dealt: " + playerIncantationDamage);

            // Enemy's turn to attack
            enemyAttack();
        }
    }                                                 
   private void enemyAttack() {
        // Randomly select the enemy type and calculate the enemy's attack
        int enemyAttackDamage = 0;
        switch (enemy) {
            case "The Elden Beast":
                enemyAttackDamage = (int) (Math.random() * (500 - 250 + 1)) + 500; // Random damage between 150-300
                battleText.setText("The Elden Beast attacked. Damage dealt: " + enemyAttackDamage);
                break;             
        }
        playerHealth -= enemyAttackDamage;
        playerHP.setText(String.valueOf(playerHealth));
        // Check if player's health drops to 0
        if (playerHealth <= 0) {
            playerHealth = 0;
            System.out.println("Your health is: " + pHealth);
            JOptionPane.showMessageDialog(this, "You have been defeated! Increased your level and stats!");
            GameLobby gameLobby = new GameLobby(totalRunes, player, selectedClass, currentLevel, pHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
            gameLobby.setVisible(true);
            
            
        }
    }
    private void physicalAttackActionPerformed(java.awt.event.ActionEvent evt) {                                               
                // Calculate player's physical damage
        int runesGained;
            
        playerPhysicalDamage = (int) ((currentSTR + weaponSTR) * (1 - getEnemyPhysicalDefense()));
       
        // Update enemy health
        enemyHP -= playerPhysicalDamage;
        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            if(enemy == "Rennala, Queen of the Full Moon"){
                JOptionPane.showMessageDialog(this, "Greate Enemy Felled!"); 
                runesGained = enemyHP * 5;
            }
            else{
                JOptionPane.showMessageDialog(this, "Enemy Felled!");
                runesGained = enemyMaxHP * 2;
                System.out.println(runesGained);
            }
            battleElden.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            enemyHealth.setText(String.valueOf(enemyHP));
            // Display battle text
            battleText.setText("Player used PHYSICAL ATTACK. Damage dealt: " + playerPhysicalDamage);
            // Enemy's turn to attack
            enemyAttack();
        }
    }                                              

    private void sorcererAttackActionPerformed(java.awt.event.ActionEvent evt) {                                               
               // Calculate player's sorcery damage
        int playerSorceryDamage = (int) ((currentINT + weaponINT) * (1 - getEnemySorceryDefense()));
        // Update enemy health
        enemyHP -= playerPhysicalDamage;
        enemyHealth.setText(String.valueOf(enemyHP));
        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            if(enemy == "Rennala, Queen of the Full Moon"){
               JOptionPane.showMessageDialog(this, "Greate Enemy Felled!"); 
            }
            else{
            JOptionPane.showMessageDialog(this, "Enemy Felled!");
            }
            int runesGained = enemyMaxHP * 2;
            if(enemy == "Rennala, Queen of the Full Moon"){
                runesGained = enemyHP * 5;
            }
            battleElden.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            // Display battle text
            battleText.setText("Player used SORCERER ATTACK. Damage dealt: " + playerSorceryDamage);
            
            // Enemy's turn to attack
            enemyAttack();
        }
    }                                              

    public static void main(String args[]) {

    }

    // Variables declaration - do not modify                     
    private javax.swing.JTextField battleText;
    private javax.swing.JLabel enemyHealth;
    private javax.swing.JLabel enemyType;
    private javax.swing.JButton incantationAttack;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton physicalAttack;
    private javax.swing.JLabel playerHP;
    private javax.swing.JLabel playerLevel;
    private javax.swing.JLabel playerName;
    private javax.swing.JButton sorcererAttack;
    // End of variables declaration                   
}
