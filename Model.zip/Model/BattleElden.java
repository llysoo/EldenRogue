package Model;

import View.GameLobby;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class BattleElden extends javax.swing.JFrame implements KeyListener {
    private int spawnTilesCount;
    private String enemyType;
    private char[][] floor1;
    private char[][] floor2;
    private char[][] floor3; 
    private char[][] floor4; 
    private char[][] floor5; 
    private int currentFloor;
    private int playerRow;
    private int playerCol;
    
    private int runes;
    private final String playerName;
    private final int currentLevel;
    private final int currentHealth;
    private final String currentClass;
    private final int currentDEX;
    private final int currentSTR;
    private final int currentINT;
    private final int currentEND;
    private final int currentFTH;
    
    public BattleElden(int runes, String playerName, String selectedClass, int currentLevel, int currentHealth, int currentDEX, int currentSTR, int currentINT, int currentEND, int currentFTH) {
        initComponents();
        // Initialize the FastTravel frame with the provided parameters
        this.runes = runes;
        this.currentClass = selectedClass;
        this.playerName = playerName;
        this.currentLevel = currentLevel;
        this.currentHealth = currentHealth;
        this.currentDEX = currentDEX;
        this.currentSTR = currentSTR;
        this.currentINT = currentINT;
        this.currentEND = currentEND;
        this.currentFTH = currentFTH;
        initializeFloors();
        currentFloor = 1; // Starting on the first floor
        if(currentFloor == 1){
            playerRow = 7;
            playerCol = 1; // Starting player position on floor3
        }
        drawGrid();
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(Color.BLACK);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 492, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 412, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }

    private void initializeFloors() {
        

        floor1 = new char[][]{
            {' ', 'D', ' '},
            {' ', ' ', ' '},
            {' ', ' ', ' '},
            {' ', ' ', ' '},
            {' ', 'S', ' '},
            {' ', ' ', ' '},
            {' ', ' ', ' '},
            {' ', 'P', ' '},
            {' ', 'F', ' '}
        };

        floor2 = new char[][]{ 
            {' ', ' ', ' ', 'D', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', 'B', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', 'D', ' ', ' ', ' '},
        };

        floor3 = new char[][]{ 
            {' ', ' ', ' '},
            {'S', ' ', 'S'},
            {' ', ' ', ' '},
            {'S', ' ', 'S'},
            {' ', ' ', ' '},
            {'S', ' ', 'S'},
            {' ', 'D', ' '}
        };


    }

    private void drawGrid() {
        jPanel1.removeAll();

        char[][] currentFloorGrid;
        switch (currentFloor) {
            case 1 -> currentFloorGrid = floor1;
            case 2 -> currentFloorGrid = floor2;
            case 3 -> currentFloorGrid = floor3;
            default -> throw new IllegalStateException("Unexpected value: " + currentFloor);
        }

        int rows = currentFloorGrid.length;
        int cols = currentFloorGrid[0].length;

        jPanel1.setLayout(new GridLayout(rows, cols));

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                JButton tileButton = createTileButton(currentFloorGrid[i][j]);
                jPanel1.add(tileButton);
            }
        }

        jPanel1.revalidate();
        jPanel1.repaint();
    }

 private JButton createTileButton(char tileType) {
    JButton tileButton = new JButton();
    tileButton.setPreferredSize(new java.awt.Dimension(70, 70));
    tileButton.setFocusPainted(false);
    tileButton.setContentAreaFilled(false);
    tileButton.setOpaque(true);
    tileButton.setText(String.valueOf(tileType));

    switch (currentFloor) {
        case 1 -> {
            }
        case 2 -> {
            }
        case 3 -> {
            }
        default -> throw new IllegalStateException("Unexpected value: " + currentFloor);
    }

    switch (tileType) {
        case 'D' -> {
            tileButton.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 2));
            tileButton.setBackground(Color.YELLOW); // Set background color to yellow
        }
        case 'S' -> {
            tileButton.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
            tileButton.setBackground(Color.BLUE); // Set background color to blue
        }
        case 'P' -> {
            tileButton.setBorder(BorderFactory.createLineBorder(Color.GREEN, 2));
            tileButton.setBackground(Color.GREEN); // Set background color to green
        }
        case 'B' -> {
            tileButton.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
            tileButton.setBackground(Color.RED); // Set background color to red
        }
        case 'O' -> tileButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        case 'F' -> tileButton.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        default -> tileButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }
    return tileButton;
}
    @Override
    public void keyTyped(KeyEvent e) {
        // Not needed for this example
    }

@Override
public void keyPressed(KeyEvent e) {
    int keyCode = e.getKeyCode();
    switch (keyCode) {
        case KeyEvent.VK_W -> movePlayer(-1, 0); // Move up
        case KeyEvent.VK_S -> movePlayer(1, 0);  // Move down
        case KeyEvent.VK_A -> movePlayer(0, -1); // Move left
        case KeyEvent.VK_D -> movePlayer(0, 1);  // Move right
    }
}

private void movePlayer(int rowChange, int colChange) {
    int newRow = playerRow + rowChange;
    int newCol = playerCol + colChange;
    
    
    if (isValidMove(newRow, newCol)) {
        char[][] currentFloorGrid;
        switch (currentFloor) {
            case 1 -> currentFloorGrid = floor1;
            case 2 -> currentFloorGrid = floor2;
            case 3 -> currentFloorGrid = floor3;
            default -> throw new IllegalStateException("Unexpected value: " + currentFloor);
        }
        // Clear player's position on the current floor
        currentFloorGrid[playerRow][playerCol] = ' ';
        
        switch (currentFloorGrid[newRow][newCol]) {
            case 'D' -> {
                // Player reached a door, prompt to change floor
                int choice = JOptionPane.showConfirmDialog(this, "Do you want to go through the door?", "Door", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    if (currentFloor == 1){
                      floor2[5][3] = 'P';
                      currentFloor = 2;
                      playerRow = 5;
                      playerCol = 3;
                    } else if(currentFloor == 2){
                        if(newRow == 6 && newCol == 3){
                           floor1[1][1] = 'P'; 
                           currentFloor = 1;
                           playerRow = 1;
                           playerCol = 1;
                        } else{
                            floor3[5][1] = 'P'; 
                            currentFloor = 3;
                            playerRow = 5;
                            playerCol = 1;
                        }
                    } else if(currentFloor == 3){
                        floor2[1][3] = 'P';
                        currentFloor = 2;
                        playerRow = 1;
                        playerCol = 3;
                    }
                    drawGrid();
                    return;
                }
            }
            case 'B' -> {
                JOptionPane.showMessageDialog(this, "Boss encounter! Prepare for battle with The Elden Beast!");
                enemyType = "The Elden Beast";
                new BattleEldenEnemy(runes, enemyType, currentFloor, playerName, currentLevel, currentHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH, this).setVisible(true);
                currentFloorGrid[playerRow][playerCol] = ' ';
                currentFloorGrid[newRow][newCol] = 'P'; // Remove the treasure tile
                playerRow = newRow; // Update player's row position
                playerCol = newCol; // Update player's column position
                drawGrid(); // Redraw the grid
            }
            case 'F' -> {
                // Player encountered the 'F' tile on the third floor, go to game lobby
                JOptionPane.showMessageDialog(this, "Fast Travel to Game Lobby!");
                GameLobby gameLobby = new GameLobby(runes, playerName, currentClass, currentLevel, currentHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
                gameLobby.setVisible(true);
                // Close the current StormBattle frame
                dispose();
            }
            case 'S' -> {
                    int treasureAmount = (int) (Math.random() * 101) + 50; // Randomize treasure amount between 50 and 150
                    JOptionPane.showMessageDialog(this, "You found treasure! You got " + treasureAmount + " runes!");
                    currentFloorGrid[playerRow][playerCol] = ' ';
                    currentFloorGrid[newRow][newCol] = 'P'; // Remove the treasure tile
                    playerRow = newRow; // Update player's row position
                    playerCol = newCol; // Update player's column position
                    runes += treasureAmount;
                    drawGrid(); // Redraw the grid
                    JOptionPane.showMessageDialog(this, "You have " + runes + "!");
            }
            default -> {
                // Normal move
                currentFloorGrid[playerRow][playerCol] = ' '; // Clear current position
                playerRow = newRow;
                playerCol = newCol;
                currentFloorGrid[playerRow][playerCol] = 'P'; // Update player's new position
                drawGrid(); // Draw the updated grid
            }
        }
        // Update player's position and draw grid
        playerRow = newRow;
        playerCol = newCol;
        currentFloorGrid[playerRow][playerCol] = 'P'; // Update player's new position
        drawGrid(); // Draw the updated grid
       
    }
}

    private boolean isValidMove(int newRow, int newCol) {
        char[][] currentFloorGrid;
        switch (currentFloor) {
            case 1 -> currentFloorGrid = floor1;
            case 2 -> currentFloorGrid = floor2;
            case 3 -> currentFloorGrid = floor3;
            case 4 -> currentFloorGrid = floor4;
            case 5 -> currentFloorGrid = floor5;
            default -> throw new IllegalStateException("Unexpected value: " + currentFloor);
        }

        int rows = currentFloorGrid.length;
        int cols = currentFloorGrid[0].length;

        return newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols;
    }
    // Method to update runes count after defeating an enemy
    public void updateRunes(int runesGained) {
        runes += runesGained;
        JOptionPane.showMessageDialog(this, "You defeated the " + enemyType + "!");
        JOptionPane.showMessageDialog(this, "You gained " + runesGained + "!");
        JOptionPane.showMessageDialog(this, "You have a total of " + runes + "!");
    }
    @Override
    public void keyReleased(KeyEvent e) {
        // Not needed for this example
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
        });
    }

    private javax.swing.JPanel jPanel1;
}

