
package Model;

import View.GameLobby;
import javax.swing.JOptionPane;

public class BattleRayaEnemy extends javax.swing.JFrame {
    private static final int ROWS = 7;
    private static final int COLS = 3;
    private char[][] floor1;
    private char[][] floor2;
    private char[][] floor3; // Added floor3
    private int currentFloor;
    private int enemyHP;
    private String enemy;
    private int totalRunes;
    private String selectedClass;
    private int currentLevel;
    private int pHealth;
    private int currentDEX;
    private String player;
    private int currentSTR;
    private int currentINT;
    private int currentEND;
    private int currentFTH;
    private int enemyMaxHP;
    private int weaponSTR; // Add weapon's strength attribute
    private int weaponINT; // Add weapon's intelligence attribute
    private int weaponFTH; // Add weapon's faith attribute
    private int Health;
    private int playerHealth;
    private int playerPhysicalDamage;
    private BattleRaya battleRaya; // Add a reference to StormBattle

    public BattleRayaEnemy(int runes, String enemyName, int currentFloor, String name, int initialLevel, int initialHealth, int initialDEX, int initialSTR, int initialINT, int initialEND, int initialFTH, BattleRaya battleRaya) {
        initComponents();
        setLocationRelativeTo(null);
        enemyType.setText(enemyName);
        this.player = name;
        // Randomize enemy HP based on floor and a range (20-30)
        int baseHP = 20;
        int hpRange = 10; // The range of HP variation
        int minHP = baseHP + (currentFloor - 1) * hpRange;
        int maxHP = minHP + hpRange;
        this.battleRaya = battleRaya; 
        this.pHealth = initialHealth;
        int weaponHealth = 0;
        initialHealth = 100 * ((initialHealth + weaponHealth) / 2);
        this.Health = initialHealth;
        this.enemy = enemyName;
        playerName.setText(String.valueOf(name));
        playerHP.setText(String.valueOf(initialHealth));
        playerLevel.setText(String.valueOf(initialLevel));
        playerName.setText(String.valueOf(name));
        playerHP.setText(String.valueOf(initialHealth));
        playerLevel.setText(String.valueOf(initialLevel));
        this.playerHealth = initialHealth;
        this.currentLevel = initialLevel;
        this.totalRunes = runes;
        this.currentDEX = initialDEX;
        this.currentSTR = initialSTR;
        this.currentINT = initialINT;
        this.currentEND = initialEND;
        this.currentFTH = initialFTH;
        this.weaponSTR = 0;
        this.weaponINT = 0;
        this.weaponFTH = 0;
        if(enemyType.equals("Rennala, Queen of the Full Moon")){
            this.enemyHP = 400;
            System.out.println(enemyHP);
        }
        else{
            // Randomize enemy HP within the specified range
            int enemyHP = (int) ((Math.random() * (maxHP - minHP + 1)) + minHP) * 3;
            this.enemyHP = enemyHP;
            if(enemy == "Living Jar"){
                this.enemyMaxHP = 30;
            } else if(enemy == "Glinstone Sorcerer"){
                this.enemyMaxHP = 35;
            } else{
                this.enemyMaxHP = 80;
            }
            this.enemyMaxHP = enemyHP;
        }
        enemyHealth.setText(String.valueOf(enemyHP));
    }

     private double getEnemyPhysicalDefense() {
        switch (enemy) {
            case "Living Jar":
                return 0.2; // 20% defense
            case "Glinstone Sorcerer":
                return 0.5; // 50% defense
            case "Battlemage":
                return 0.25; // 25% defense
            case "Rennala, Queen of the Full Moon":
                return 0.15;
            default:
                return 0.0;
        }
    }
         private double getEnemySorceryDefense() {
        switch (enemy) {
            case "Living Jar":
                return 0.15; // 15% defense
            case "Glinstone Sorcerer":
                return 0.15; // 15% defense
            case "Battlemage":
                return 0.25; // 25% defense
            case "Rennala, Queen of the Full Moon":
                return 0.35;
            default:
                return 0.0;
        }
    }

    private double getEnemyIncantationDefense() {
        switch (enemy) {
            case "Living Jar":
                return 0.1; // 10% defense
            case "Glinstone Sorcerer":
                return 0.2; // 20% defense
            case "Battlemage":
                return 0.2; // 20% defense
            case "Rennala, Queen of the Full Moon":
                return 0.4;
            default:
                return 0.0;
        }
    }                                              

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        playerName = new javax.swing.JLabel();
        playerLevel = new javax.swing.JLabel();
        playerHP = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        enemyType = new javax.swing.JLabel();
        enemyHealth = new javax.swing.JLabel();
        physicalAttack = new javax.swing.JButton();
        sorcererAttack = new javax.swing.JButton();
        incantationAttack = new javax.swing.JButton();
        battleText = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Viner Hand ITC", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 0));
        jLabel1.setText("RAYA LUCARIA ACADEMY BATTLE");

        jLabel2.setForeground(new java.awt.Color(255, 153, 51));
        jLabel2.setText("Player Name:");

        jLabel3.setForeground(new java.awt.Color(255, 153, 51));
        jLabel3.setText("Player Level:");

        jLabel4.setForeground(new java.awt.Color(255, 153, 51));
        jLabel4.setText("Health:");

        playerName.setForeground(new java.awt.Color(255, 153, 0));
        playerName.setText("jLabel5");

        playerLevel.setForeground(new java.awt.Color(255, 153, 0));
        playerLevel.setText("jLabel6");

        playerHP.setForeground(new java.awt.Color(255, 153, 0));
        playerHP.setText("jLabel7");

        jLabel8.setForeground(new java.awt.Color(255, 153, 0));
        jLabel8.setText("Enemy Name:");

        jLabel9.setForeground(new java.awt.Color(255, 153, 0));
        jLabel9.setText("Health:");

        enemyType.setForeground(new java.awt.Color(255, 153, 0));
        enemyType.setText("jLabel10");

        enemyHealth.setForeground(new java.awt.Color(255, 153, 0));
        enemyHealth.setText("jLabel11");

        physicalAttack.setBackground(new java.awt.Color(153, 255, 153));
        physicalAttack.setText("PHYSICAL ATTACK");
        physicalAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                physicalAttackActionPerformed(evt);
            }
        });

        sorcererAttack.setBackground(new java.awt.Color(255, 153, 255));
        sorcererAttack.setText("SORCERER ATTACK");
        sorcererAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sorcererAttackActionPerformed(evt);
            }
        });

        incantationAttack.setBackground(new java.awt.Color(255, 102, 102));
        incantationAttack.setText("INCANTATION ATTACK");
        incantationAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                incantationAttackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel4))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(108, 108, 108)
                                        .addComponent(playerName))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(playerLevel, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(playerHP, javax.swing.GroupLayout.Alignment.TRAILING))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addGap(61, 61, 61)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(enemyType)
                                    .addComponent(enemyHealth))
                                .addGap(49, 49, 49))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(108, 108, 108)
                                .addComponent(sorcererAttack)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(physicalAttack)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(incantationAttack)
                        .addGap(20, 20, 20))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addComponent(battleText, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(64, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(playerName)
                    .addComponent(jLabel8)
                    .addComponent(enemyType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerLevel)
                    .addComponent(jLabel9)
                    .addComponent(enemyHealth)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(playerHP))
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(physicalAttack)
                    .addComponent(sorcererAttack)
                    .addComponent(incantationAttack))
                .addGap(18, 18, 18)
                .addComponent(battleText, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void physicalAttackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_physicalAttackActionPerformed
        // TODO add your handling code here:
        // Calculate player's physical damage
        int runesGained;
            
        playerPhysicalDamage = (int) ((currentSTR + weaponSTR) * (1 - getEnemyPhysicalDefense()));
       
        // Update enemy health
        enemyHP -= playerPhysicalDamage;
        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            if(enemy == "Rennala, Queen of the Full Moon"){
                JOptionPane.showMessageDialog(this, "Greate Enemy Felled!"); 
                runesGained = enemyHP * 5;
            }
            else{
                JOptionPane.showMessageDialog(this, "Enemy Felled!");
                runesGained = enemyMaxHP * 2;
                System.out.println(runesGained);
            }
            battleRaya.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            enemyHealth.setText(String.valueOf(enemyHP));
            // Display battle text
            battleText.setText("Player used PHYSICAL ATTACK. Damage dealt: " + playerPhysicalDamage);
            // Enemy's turn to attack
            enemyAttack();
        }
    }//GEN-LAST:event_physicalAttackActionPerformed

    private void sorcererAttackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sorcererAttackActionPerformed
        // TODO add your handling code here:
        // Calculate player's sorcery damage
        int playerSorceryDamage = (int) ((currentINT + weaponINT) * (1 - getEnemySorceryDefense()));
        // Update enemy health
        enemyHP -= playerPhysicalDamage;
        enemyHealth.setText(String.valueOf(enemyHP));
        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            if(enemy == "Rennala, Queen of the Full Moon"){
               JOptionPane.showMessageDialog(this, "Greate Enemy Felled!"); 
            }
            else{
            JOptionPane.showMessageDialog(this, "Enemy Felled!");
            }
            int runesGained = enemyMaxHP * 2;
            if(enemy == "Rennala, Queen of the Full Moon"){
                runesGained = enemyHP * 5;
            }
            battleRaya.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            // Display battle text
            battleText.setText("Player used SORCERER ATTACK. Damage dealt: " + playerSorceryDamage);
            
            // Enemy's turn to attack
            enemyAttack();
        }
    }//GEN-LAST:event_sorcererAttackActionPerformed

    private void incantationAttackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_incantationAttackActionPerformed
        // TODO add your handling code here:
        // Calculate player's incantation damage
        int playerIncantationDamage = (int) ((currentFTH + weaponFTH) * (1 - getEnemyIncantationDefense()));
        // Update enemy health
        enemyHP -= playerPhysicalDamage;
        enemyHealth.setText(String.valueOf(enemyHP));
        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            if(enemy == "Rennala, Queen of the Full Moon"){
               JOptionPane.showMessageDialog(this, "Greate Enemy Felled!"); 
            }
            else{
            JOptionPane.showMessageDialog(this, "Enemy Felled!");
            }
            int runesGained = enemyMaxHP * 2;
            if(enemy == "Godrick the Grafted"){
                runesGained = enemyHP * 5;
            }
            battleRaya.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            // Update enemy health
            enemyHP -= playerIncantationDamage;
            enemyHealth.setText(String.valueOf(enemyHP));
            // Display battle text
            battleText.setText("Player used INCANTATION ATTACK. Damage dealt: " + playerIncantationDamage);

            // Enemy's turn to attack
            enemyAttack();
        }
    }//GEN-LAST:event_incantationAttackActionPerformed
    private void enemyAttack() {
        // Randomly select the enemy type and calculate the enemy's attack
        int enemyAttackDamage = 0;
        switch (enemy) {
            case "Living Jar":
                enemyAttackDamage = (int) (Math.random() * (80 - 70 + 1)) + 70; // Random damage between 70 and 80
                battleText.setText("Living Jar attacked. Damage dealt: " + enemyAttackDamage);
                break;
            case "Glinstone Sorcerer":
                enemyAttackDamage = (int) (Math.random() * (120 - 110 + 1)) + 110; // Random damage between 110 and 120
                battleText.setText("Glintsone Sorcerer attacked. Damage dealt: " + enemyAttackDamage);
                break;
            case "Battlemage":
                enemyAttackDamage = (int) (Math.random() * (130 - 120 + 1)) + 120; // Random damage between 120 and 130
                battleText.setText("Battlemage attacked. Damage dealt: " + enemyAttackDamage);
                break;
            case "Rennala, Queen of the Full Moon":
                enemyAttackDamage = (int) (Math.random() * (300 - 200 + 1)) + 300; // Random damage between 150-300
                battleText.setText("Rennala, Queen of the Full Moon attacked. Damage dealt: " + enemyAttackDamage);
                break;             
        }
        playerHealth -= enemyAttackDamage;
        playerHP.setText(String.valueOf(playerHealth));
        // Check if player's health drops to 0
        if (playerHealth <= 0) {
            playerHealth = 0;
            System.out.println("Your health is: " + pHealth);
            JOptionPane.showMessageDialog(this, "You have been defeated! Increased your level and stats!");
            GameLobby gameLobby = new GameLobby(totalRunes, player, selectedClass, currentLevel, pHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
            gameLobby.setVisible(true);
            
            
        }
    }
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField battleText;
    private javax.swing.JLabel enemyHealth;
    private javax.swing.JLabel enemyType;
    private javax.swing.JButton incantationAttack;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton physicalAttack;
    private javax.swing.JLabel playerHP;
    private javax.swing.JLabel playerLevel;
    private javax.swing.JLabel playerName;
    private javax.swing.JButton sorcererAttack;
    // End of variables declaration//GEN-END:variables
}
