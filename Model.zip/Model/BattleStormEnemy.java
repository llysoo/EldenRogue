
package Model;

import View.GameLobby;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class BattleStormEnemy extends javax.swing.JFrame {
    private static final int ROWS = 7;
    private static final int COLS = 3;
    private char[][] floor1;
    private char[][] floor2;
    private char[][] floor3; // Added floor3
    private int currentFloor;
    private int enemyHP;
    private String enemy;
    private int totalRunes;
    private int playerHealth;
    private String selectedClass;
    private int currentLevel;
    private int pHealth;
    private int currentDEX;
    private String player;
    private int currentSTR;
    private int currentINT;
    private int currentEND;
    private int currentFTH;
    private int enemyMaxHP;
    private int weaponSTR; // Add weapon's strength attribute
    private int weaponINT; // Add weapon's intelligence attribute
    private int weaponFTH; // Add weapon's faith attribute
    private int Health;
    private int playerPhysicalDamage;
    private int playerSorceryDamage;
    private int playerIncantationDamage;
    private StormBattle stormBattle; // Add a reference to StormBattle

    
    public BattleStormEnemy(int runes, String enemyName, int currentFloor, String name, int initialLevel, int initialHealth, int initialDEX, int initialSTR, int initialINT, int initialEND, int initialFTH, StormBattle stormBattle) {
        initComponents();
        setLocationRelativeTo(null);
        enemyType.setText(enemyName);
        this.player = name;
        // Randomize enemy HP based on floor and a range (20-30)
        int baseHP = 20;
        int hpRange = 10; // The range of HP variation
        int minHP = baseHP + (currentFloor - 1) * hpRange;
        int maxHP = minHP + hpRange;
        this.stormBattle = stormBattle; 
        this.pHealth = initialHealth;
        int weaponHealth = 0;
        initialHealth = 100 * ((initialHealth + weaponHealth) / 2);
        this.Health = initialHealth;
        this.enemy = enemyName;
        playerName.setText(String.valueOf(name));
        playerHP.setText(String.valueOf(initialHealth));
        playerLevel.setText(String.valueOf(initialLevel));
        this.playerHealth = initialHealth;
        this.currentLevel = initialLevel;
        this.totalRunes = runes;
        this.currentDEX = initialDEX;
        this.currentSTR = initialSTR;
        this.currentINT = initialINT;
        this.currentEND = initialEND;
        this.currentFTH = initialFTH;
        this.weaponSTR = 0;
        this.weaponINT = 0;
        this.weaponFTH = 0;
        if(enemyName.equals("Godrick the Grafted")){
            this.enemyHP = 200;
            System.out.println(enemyHP);
        }
        else{
            // Randomize enemy HP within the specified range
            int enemyHP = (int) ((Math.random() * (maxHP - minHP + 1)) + minHP) * 3;
            // Set the enemy HP in the enemyHealth label
            this.enemyHP = enemyHP;
            this.enemyMaxHP = enemyHP;
        }
        enemyHealth.setText(String.valueOf(enemyHP));
    }
    
    private double getEnemyPhysicalDefense() {
        switch (enemy) {
            case "Godrick Soldier":
                return 0.2; // 20% defense
            case "Godrick Archer":
                return 0.5; // 50% defense
            case "Godrick Knight":
                return 0.25; // 25% defense
            case "Godrick the Grafted":
                return 0.35;
            default:
                return 0.0;
        }
    }

    private double getEnemySorceryDefense() {
        switch (enemy) {
            case "Godrick Soldier":
                return 0.15; // 15% defense
            case "Godrick Archer":
                return 0.15; // 15% defense
            case "Godrick Knight":
                return 0.25; // 25% defense
            case "Godrick the Grafted":
                return 0.2;
            default:
                return 0.0;
        }
    }

    private double getEnemyIncantationDefense() {
        switch (enemy) {
            case "Godrick Soldier":
                return 0.1; // 10% defense
            case "Godrick Archer":
                return 0.2; // 20% defense
            case "Godrick Knight":
                return 0.2; // 20% defense
            case "Godrick the Grafted":
                return 0.15;
            default:
                return 0.0;
        }
    }
   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        playerName = new javax.swing.JLabel();
        playerLevel = new javax.swing.JLabel();
        playerHP = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        enemyType = new javax.swing.JLabel();
        enemyHealth = new javax.swing.JLabel();
        physicalAttack = new javax.swing.JButton();
        sorcererAttack = new javax.swing.JButton();
        incantationAttack = new javax.swing.JButton();
        battleText = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 102));

        jLabel1.setFont(new java.awt.Font("Stencil", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 0, 0));
        jLabel1.setText("STORMVIEL CASTLE BATTLE");

        jLabel2.setText("Player Name:");

        jLabel3.setText("Player Level:");

        jLabel4.setText("Health:");

        playerName.setText("jLabel5");

        playerLevel.setText("jLabel5");

        playerHP.setText("jLabel5");

        jLabel5.setText("Enemy Name:");

        jLabel6.setText("Enemy Health:");

        enemyType.setText("jLabel7");

        enemyHealth.setText("jLabel7");

        physicalAttack.setBackground(new java.awt.Color(153, 204, 255));
        physicalAttack.setText("PHYSICAL ATTACK");
        physicalAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                physicalAttackActionPerformed(evt);
            }
        });

        sorcererAttack.setBackground(new java.awt.Color(255, 102, 102));
        sorcererAttack.setText("SORCERER ATTACK");
        sorcererAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sorcererAttackActionPerformed(evt);
            }
        });

        incantationAttack.setBackground(new java.awt.Color(51, 255, 204));
        incantationAttack.setText("INCANTATION ATTACK");
        incantationAttack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                incantationAttackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(playerHP))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(playerLevel))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(82, 82, 82)
                                .addComponent(playerName)))
                        .addGap(51, 51, 51)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(44, 44, 44)
                                .addComponent(enemyType))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(enemyHealth))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(physicalAttack, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(sorcererAttack)
                        .addGap(27, 27, 27)
                        .addComponent(incantationAttack))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(battleText, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jLabel1)))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(playerName)
                    .addComponent(jLabel5)
                    .addComponent(enemyType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(playerLevel)
                    .addComponent(jLabel6)
                    .addComponent(enemyHealth))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(playerHP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sorcererAttack)
                    .addComponent(physicalAttack)
                    .addComponent(incantationAttack))
                .addGap(18, 18, 18)
                .addComponent(battleText, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void physicalAttackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_physicalAttackActionPerformed
        // TODO add your handling code here:
        // Calculate player's physical damage
        int runesGained;
            
        playerPhysicalDamage = (int) ((currentSTR + weaponSTR) * (1 - getEnemyPhysicalDefense()));
       
        // Update enemy health
        enemyHP -= playerPhysicalDamage;
        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            if(enemy == "Godrick the Grafted"){
                JOptionPane.showMessageDialog(this, "GREAT ENEMY FELLED!");
            }
            else{
                JOptionPane.showMessageDialog(this, "ENEMY FELLED!");
            }
            if(enemy == "Godrick the Grafted"){
                runesGained = enemyHP * 5;
            }
            else{
                runesGained = enemyMaxHP * 2;
                System.out.println(runesGained);
            }
            stormBattle.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            enemyHealth.setText(String.valueOf(enemyHP));
            // Display battle text
            battleText.setText("Player used PHYSICAL ATTACK. Damage dealt: " + playerPhysicalDamage);
            // Enemy's turn to attack
            enemyAttack();
        }
    }//GEN-LAST:event_physicalAttackActionPerformed

    private void sorcererAttackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sorcererAttackActionPerformed
        // Calculate player's sorcery damage
        
        playerSorceryDamage = (int) ((currentINT + weaponINT) * (1 - getEnemySorceryDefense()));
        
        System.out.println(playerSorceryDamage);

        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            int runesGained = enemyMaxHP * 2;
            if(enemy == "Godrick the Grafted"){
                runesGained = enemyHP * 5;
                JOptionPane.showMessageDialog(this, "GREAT ENEMY FELLED!");
            }
            else{
                JOptionPane.showMessageDialog(this, "ENEMY FELLED!");
            }
            stormBattle.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            // Display battle text
            enemyHP -= playerSorceryDamage;
            enemyHealth.setText(String.valueOf(enemyHP));
            battleText.setText("Player used SORCERER ATTACK. Damage dealt: " + playerSorceryDamage);
            
            // Enemy's turn to attack
            enemyAttack();
        }
    }//GEN-LAST:event_sorcererAttackActionPerformed

    private void incantationAttackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_incantationAttackActionPerformed
        // Calculate player's incantation damage
        playerIncantationDamage = (int) ((currentFTH + weaponFTH) * (1 - getEnemyIncantationDefense()));
        // Update enemy health
        enemyHP -= playerPhysicalDamage;
        enemyHealth.setText(String.valueOf(enemyHP));
        
        // Check if the enemy is defeated
        if (enemyHP <= 0) {
            enemyHP = 0;
            enemyHealth.setText(String.valueOf(enemyHP));
            int runesGained = enemyMaxHP * 2;
            if(enemy == "Godrick the Grafted"){
                runesGained = enemyHP * 5;
                JOptionPane.showMessageDialog(this, "GREAT ENEMY FELLED!");
            }
            else{
                JOptionPane.showMessageDialog(this, "ENEMY FELLED!");
            }
            stormBattle.updateRunes(runesGained);
            dispose(); // Close the BattleStormEnemy frame
        } else {
            // Update enemy health
            enemyHP -= playerIncantationDamage;
            enemyHealth.setText(String.valueOf(enemyHP));
            // Display battle text
            battleText.setText("Player used INCANTATION ATTACK. Damage dealt: " + playerIncantationDamage);

            // Enemy's turn to attack
            enemyAttack();
        }
    }//GEN-LAST:event_incantationAttackActionPerformed
    private void enemyAttack() {
        // Randomly select the enemy type and calculate the enemy's attack
        int enemyAttackDamage = 0;
        switch (enemy) {
            case "Godrick Soldier":
                enemyAttackDamage = (int) (Math.random() * (80 - 70 + 1)) + 70; // Random damage between 70 and 80
                battleText.setText("Godrick Soldier attacked. Damage dealt: " + enemyAttackDamage);
                break;
            case "Godrick Archer":
                enemyAttackDamage = (int) (Math.random() * (120 - 110 + 1)) + 110; // Random damage between 110 and 120
                battleText.setText("Godrick Archer attacked. Damage dealt: " + enemyAttackDamage);
                break;
            case "Godrick Knight":
                enemyAttackDamage = (int) (Math.random() * (130 - 120 + 1)) + 120; // Random damage between 120 and 130
                battleText.setText("Godrick Knight attacked. Damage dealt: " + enemyAttackDamage);
                break;
            case "Godrick the Grafted":
                enemyAttackDamage = (int) (Math.random() * (300 - 150 + 1)) + 300; // Random damage between 150 - 300
                battleText.setText("Godrick Knight attacked. Damage dealt: " + enemyAttackDamage);
                break;             
        }
        playerHealth -= enemyAttackDamage;
        playerHP.setText(String.valueOf(playerHealth));
        // Check if player's health drops to 0
        if (playerHealth <= 0) {
            playerHealth = 0;
            System.out.println("Your health is: " + pHealth);
            JOptionPane.showMessageDialog(this, "You have been defeated! Increased your level and stats!");
            GameLobby gameLobby = new GameLobby(totalRunes, player, selectedClass, currentLevel, pHealth, currentDEX, currentSTR, currentINT, currentEND, currentFTH);
            gameLobby.setVisible(true);
            
        }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BattleStormEnemy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BattleStormEnemy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BattleStormEnemy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BattleStormEnemy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField battleText;
    private javax.swing.JLabel enemyHealth;
    private javax.swing.JLabel enemyType;
    private javax.swing.JButton incantationAttack;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton physicalAttack;
    private javax.swing.JLabel playerHP;
    private javax.swing.JLabel playerLevel;
    private javax.swing.JLabel playerName;
    private javax.swing.JButton sorcererAttack;
    // End of variables declaration//GEN-END:variables
}
